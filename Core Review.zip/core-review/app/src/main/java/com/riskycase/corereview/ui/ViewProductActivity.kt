package com.riskycase.corereview.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.riskycase.corereview.R

class ViewProductActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_product)
        Toast.makeText(baseContext, (intent.getSerializableExtra("product") as Product).title, Toast.LENGTH_SHORT).show()
    }
}