package com.riskycase.corereview.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.riskycase.corereview.R

class AccountActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account)
    }
}